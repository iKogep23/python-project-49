### Hexlet tests and linter status:
[![Actions Status](https://github.com/iKogep23/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/iKogep23/python-project-49/actions)

[![Brain-even game video](https://asciinema.org/a/R6pETdqCXAxmCBydtrwrUuDUR.svg)](https://asciinema.org/a/R6pETdqCXAxmCBydtrwrUuDUR)

[![Brain-calc game video](https://asciinema.org/a/7UqBZsLm9o5VaLRhhRVfOyNkX.svg)](https://asciinema.org/a/7UqBZsLm9o5VaLRhhRVfOyNkX)

[![Brain-gcd game video](https://asciinema.org/a/0tXt01gsmkva638S0m4lMWj7i.svg)](https://asciinema.org/a/0tXt01gsmkva638S0m4lMWj7i)

[![Brain-progression game video](https://asciinema.org/a/T8iZQl4mmO7EXX5GGRsbxIILe.svg)](https://asciinema.org/a/T8iZQl4mmO7EXX5GGRsbxIILe)

[![Brain-prime game video](https://asciinema.org/a/KggpAfqge5FFmYcvfr2gE6QBx.svg)](https://asciinema.org/a/KggpAfqge5FFmYcvfr2gE6QBx)

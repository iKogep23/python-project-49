### Hexlet tests and linter status:
[![Actions Status](https://github.com/iKogep23/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/iKogep23/python-project-49/actions)

[![asciicast](https://asciinema.org/a/R6pETdqCXAxmCBydtrwrUuDUR.svg)](https://asciinema.org/a/R6pETdqCXAxmCBydtrwrUuDUR)

[![asciicast](https://asciinema.org/a/7UqBZsLm9o5VaLRhhRVfOyNkX.svg)](https://asciinema.org/a/7UqBZsLm9o5VaLRhhRVfOyNkX)
